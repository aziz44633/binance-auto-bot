# Binance Auto Bot

This is an example of a simple Binance trading bot.