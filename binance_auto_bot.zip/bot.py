
import time

def run_bot():
    print("Starting Binance auto bot...")
    while True:
        print("Checking market data...")
        # محاكاة تداول
        time.sleep(10)

if __name__ == "__main__":
    run_bot()
